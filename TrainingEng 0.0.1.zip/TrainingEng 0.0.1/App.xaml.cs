﻿using System.Windows;

namespace TrainingEng_0._0._1
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
